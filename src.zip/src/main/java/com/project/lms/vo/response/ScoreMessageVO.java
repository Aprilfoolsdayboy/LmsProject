package com.project.lms.vo.response;

public class ScoreMessageVO {
    String Explanation;
}
