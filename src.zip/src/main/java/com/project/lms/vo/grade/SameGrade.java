package com.project.lms.vo.grade;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

public interface SameGrade {
    Integer getTotalSum();
    String getStudent();
}
