package com.project.lms.entity;

import com.project.lms.entity.member.EmployeeInfo;

import jakarta.persistence.*;
<<<<<<< HEAD
import lombok.AccessLevel;
=======
import lombok.AllArgsConstructor;
>>>>>>> ddd321e202580b3a5ffc053e5b28bbbe489cecdc
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Table(name = "class_info")
@AllArgsConstructor
@Getter
@NoArgsConstructor
public class ClassInfoEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ci_seq")
    private Long ciSeq;

    @Column(name = "ci_name", nullable = false, length = 20)
    private String ciName;

    @Column(name = "ci_limit", nullable = false)
    private Integer ciLimit;

    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "ci_mi_seq", nullable = false)
    private EmployeeInfo employee;

    public Long getCiSeq(){
        return ciSeq;
    }
}
